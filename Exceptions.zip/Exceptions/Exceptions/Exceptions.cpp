// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Mark Holden
// CS-405 Secure Coding
// 9/25/2022
// 
// Process Summary: The first step I took, since I only know custom .Net exceptions by heart,
// was to Google for a custom C++ exception. Unfortunately, the solution found at https://rollbar.com/blog/cpp-custom-exceptions/
// does not work. It works well enough to continue coding the project. I went top to bottom in the file and coded
// each TODO systematically in that manner. Once I reached the bottom, I ran the code and did not
// get the SecureCodingException that I expected because there was an issue with the custom exception
// After messing around for about 2 hours with different compiler errors related to different things 
// cannot be converted to char*, I gave up and searched for another online guide that sucks less.
// Fortunately Peter Forgacs came to my rescue with his article here https://peterforgacs.github.io/2017/06/25/Custom-C-Exceptions-For-Beginners/
// Once I referenced his solution, I was able to rapidly fix the issues that were preventing the
// correct error from being thrown, and the program completed as expected with the SecureCodingException
// being caught.
// 
// Output:
// Exceptions Tests!
// Error was captured : You can't divide by zero
// Running Custom Application Logic.
// Error occurred : Exception while processing do_even_more_custom_application_logic
// SecureCodingException occurred : Something wasn't secure enough
//

#include <iostream>

/// <summary>
/// Throw this exception when code is not secure.
/// </summary>
class SecureCodingException : public std::exception
{
public:
    SecureCodingException(const char* message) : std::exception(message) {}
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::exception("Exception while processing do_even_more_custom_application_logic");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception ex)
    {
        std::cout << "Error occurred: " << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw SecureCodingException("Something wasn't secure enough");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f)
        throw std::runtime_error("You can't divide by zero");

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error ex)
    {
        std::cout << "Error was captured: " << ex.what() << std::endl;
    }
}

int main()
{
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    catch (SecureCodingException& sce)
    {
        std::cout << "SecureCodingException occurred: " << sce.what() << std::endl;
    }
    catch (std::exception& ex)
    {
        std::cout << "std::exception occurred: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Uncaught Exception occurred" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

