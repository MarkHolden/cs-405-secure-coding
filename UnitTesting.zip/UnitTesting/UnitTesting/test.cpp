// 
// Mark Holden
// 9/25/2022
// CS-405 Secure Code
// 
// Process Summary:
// The process that I followed to complete the assignment was to start from the top of the
// file and work my way down, completing any TODOs as I encountered them. The first challenge
// I encountered was attempting to use a parameterized test. This is trivial with Xunit or NUnit
// in .Net, but there is quite a bit of setup required in C++ and Google Tests. Fortunately,
// Sandor Dargo had some examples that could be adapted to work for what I needed. Once the
// parameterized tests were complete, it was smooth sailing until I tried to assert that 
// pop_back throws an error when the list is empty. It does not throw, there is an _STL_VERIFY
// in the code that prevents the condition from occuring. When I found that, I changed my test
// to another negative test case (Empty_ShouldReturnFalseWhenCollectionIsNotEmpty).

// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::TestWithParam<int>
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    // number of entries to add in parameterized tests
    int entriesToAdd;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        //assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_EQ((size_t)0, collection->size());

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_EQ((size_t)1, collection->size());
}

// Verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    ASSERT_EQ((size_t)5, collection->size());
}

class CollectionTestFixture :public ::testing::TestWithParam<int> {
protected:
    int entriesToAdd;
};

INSTANTIATE_TEST_CASE_P(CollectionTest, CollectionTest,
    testing::Values(0, 1, 5, 10));

// Verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_P(CollectionTest, MaxSize_ShouldBeGreaterThan)
{
    int entriesToAdd = GetParam();
    add_entries(entriesToAdd);

    ASSERT_TRUE(collection->max_size() >= collection->size());
}

//Verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_P(CollectionTest, Capacity_ShouldBeGreaterThan)
{
    int entriesToAdd = GetParam();
    add_entries(entriesToAdd);

    ASSERT_TRUE(collection->capacity() >= collection->size());
}

// Verify resizing increases the collection
TEST_F(CollectionTest, Resize_ShouldIncreaseCollectionSize)
{
    add_entries(5);
    collection->resize(7);

    ASSERT_EQ((size_t)7, collection->size());
}

// Verify resizing decreases the collection
TEST_F(CollectionTest, Resize_ShouldDecreaseCollectionSize)
{
    add_entries(5);
    collection->resize(3);

    ASSERT_EQ((size_t)3, collection->size());
}

// Verify resizing decreases the collection to zero
TEST_F(CollectionTest, Resize_ShouldIncreaseCollectionSizeToZero)
{
    add_entries(5);
    collection->resize(0);

    ASSERT_EQ((size_t)0, collection->size());
}

// Verify clear erases the collection
TEST_F(CollectionTest, Clear_ShouldEraseCollection)
{
    add_entries(5);
    collection->clear();

    ASSERT_EQ((size_t)0, collection->size());
}

//Verify erase(begin,end) erases the collection
TEST_F(CollectionTest, Erase_ShouldEraseCollection)
{
    add_entries(5);
    collection->erase(collection->begin(), collection->end());

    ASSERT_EQ((size_t)0, collection->size());
}

// Verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, Reserve_ShouldIncreaseCapacity_ButNotSize)
{
    add_entries(5);
    collection->reserve(7);

    ASSERT_EQ((size_t)5, collection->size());
    ASSERT_EQ((size_t)7, collection->capacity());
}

// Verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, At_ShouldThrowOutOfRangeException_WhenIndexOutOfBounds)
{
    add_entries(5);

    ASSERT_THROW(collection->at(7), std::out_of_range);
}

TEST_F(CollectionTest, PushBack_ShouldAddValueToLastIndex)
{
    collection->push_back(1492);

    ASSERT_EQ(1492, collection->at(collection->size() - 1));
}

TEST_F(CollectionTest, PopBack_ShouldRemoveLastIndex)
{
    add_entries(5);
    collection->push_back(1492);
    collection->pop_back();

    ASSERT_FALSE(1492 == collection->at(collection->size() - 1));
}

TEST_F(CollectionTest, Empty_ShouldReturnTrueWhenCollectionIsEmpty)
{
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, Empty_ShouldReturnFalseWhenCollectionIsNotEmpty)
{
    add_entries(5);

    ASSERT_FALSE(collection->empty());
}

